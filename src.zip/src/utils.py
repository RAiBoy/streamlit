import numpy as np
import pandas as pd

from keras.preprocessing import sequence
from keras.preprocessing.text import Tokenizer

from sklearn.model_selection import train_test_split


class Preprocessing:
	
	def __init__(self, args):
		self.data = '../data/document_classification/mesh.csv'
		self.max_len = args.max_len
		self.max_words = args.max_words
		self.test_size = args.test_size
		
	def load_data(self):
		df = pd.read_csv(self.data)
		df = df.dropna()
  
		#df.drop(['id','keyword','location'], axis=1, inplace=True)
		names = list(df.label.unique()) 
		id = list(range(len(names)))
		name2id = {n:i for n, i in zip(names, id)} 
		df['target'] = df.apply(lambda x: name2id[x['label']], axis=1)
		
		X = df['text'].values
		Y = df['target'].values
		
		self.num_class = len(names)
		self.x_train, self.x_test, self.y_train, self.y_test = train_test_split(X, Y, test_size=self.test_size)
		
	def prepare_tokens(self):
		self.tokens = Tokenizer(num_words=self.max_words)
		self.tokens.fit_on_texts(self.x_train)

	def sequence_to_token(self, x):
		sequences = self.tokens.texts_to_sequences(x)
		return sequence.pad_sequences(sequences, maxlen=self.max_len)


# =========== DOC CLASSIFICATION ===========
import torch
from tqdm.notebook import tqdm
from transformers import BertTokenizer
from torch.utils.data import DataLoader, RandomSampler, SequentialSampler
from torch.utils.data import TensorDataset
import random
import numpy as np
from sklearn.metrics import f1_score


seed_val = 17
random.seed(seed_val)
np.random.seed(seed_val)
torch.manual_seed(seed_val)
torch.cuda.manual_seed_all(seed_val)


def get_dataloader(X, Y, batch_size, tokenizer):
    encoded_data_train = tokenizer.batch_encode_plus(
        X, 
        add_special_tokens=True, 
        return_attention_mask=True, 
        padding=True, 
        max_length=512, 
        return_tensors='pt',
        truncation = True,
    )

    input_ids_train = encoded_data_train['input_ids']
    attention_masks_train = encoded_data_train['attention_mask']
    labels_train = torch.tensor(Y)

    dataset_train = TensorDataset(input_ids_train, attention_masks_train, labels_train)
    dataloader = DataLoader(dataset_train, 
                            sampler=RandomSampler(dataset_train), 
                            batch_size=batch_size)

    return dataloader


def get_dataloaders_old(df, batch_size, tokenizer):
    encoded_data_train = tokenizer.batch_encode_plus(
        df[df.data_type=='train'].Text.values, 
        add_special_tokens=True, 
        return_attention_mask=True, 
        padding=True, 
        max_length=512, 
        return_tensors='pt',
        truncation = True,
    )

    encoded_data_val = tokenizer.batch_encode_plus(
        df[df.data_type=='val'].Text.values, 
        add_special_tokens=True, 
        return_attention_mask=True, 
        padding=True, 
        max_length=512, 
        return_tensors='pt',
        truncation = True,
    )


    input_ids_train = encoded_data_train['input_ids']
    attention_masks_train = encoded_data_train['attention_mask']
    labels_train = torch.tensor(df[df.data_type=='train'].label.values)

    input_ids_val = encoded_data_val['input_ids']
    attention_masks_val = encoded_data_val['attention_mask']
    labels_val = torch.tensor(df[df.data_type=='val'].label.values)

    dataset_train = TensorDataset(input_ids_train, attention_masks_train, labels_train)
    dataset_val = TensorDataset(input_ids_val, attention_masks_val, labels_val)
    dataloader_train = DataLoader(dataset_train, 
                                  sampler=RandomSampler(dataset_train), 
                                  batch_size=batch_size)

    dataloader_validation = DataLoader(dataset_val, 
                                       sampler=SequentialSampler(dataset_val), # WHY?
                                       batch_size=batch_size)
    return dataloader_train, dataloader_validation

def f1_score_func(preds, labels):
    preds_flat = np.argmax(preds, axis=1).flatten()
    labels_flat = labels.flatten()
    return f1_score(labels_flat, preds_flat, average='weighted')

def accuracy_per_class(preds, labels):
    label_dict_inverse = {v: k for k, v in label_dict.items()}
    
    preds_flat = np.argmax(preds, axis=1).flatten()
    labels_flat = labels.flatten()

    for label in np.unique(labels_flat):
        y_preds = preds_flat[labels_flat==label]
        y_true = labels_flat[labels_flat==label]
        print(f'Class: {label_dict_inverse[label]}')
        print(f'Accuracy: {len(y_preds[y_preds==label])}/{len(y_true)}\n')


def evaluate(model, dataloader_val, device):

    model.eval()
    
    loss_val_total = 0
    predictions, true_vals = [], []
    
    for batch in dataloader_val:
        
        batch = tuple(b.to(device) for b in batch)
        
        inputs = {'input_ids':      batch[0],
                  'attention_mask': batch[1],
                  'labels':         batch[2],
                 }
        
        with torch.no_grad():        
            outputs = model(**inputs)
            
        loss = outputs[0]
        logits = outputs[1]
        loss_val_total += loss.item()

        logits = logits.detach().cpu().numpy()
        label_ids = inputs['labels'].cpu().numpy()
        predictions.append(logits)
        true_vals.append(label_ids)
    
    loss_val_avg = loss_val_total/len(dataloader_val) 
    
    predictions = np.concatenate(predictions, axis=0)
    true_vals = np.concatenate(true_vals, axis=0)
            
    return loss_val_avg, predictions, true_vals
    
def get_y_pred(preds,labels):
    label_dict_inverse = {v: k for k, v in label_dict.items()}
    y_true = np.argmax(preds, axis=1).flatten()
    y_pred = labels.flatten()
    return y_true,y_pred